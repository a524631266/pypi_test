#This is just so that you can verify that it installed correctly later in this tutorial.
name = "test"