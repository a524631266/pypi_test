#This is just so that you can verify that it installed correctly later in this tutorial.
import requests
import test.module1 as module1
from test.module1 import runcmd as runcmd
name = "tes2234"
