from test.module1 import runcmd

def runcmd1():
    runcmd()